import pygame
from os.path import join
import asyncio

# general setup
pygame.init()
WINDOW_WIDTH, WINDOW_HEIGHT = 1280, 720
display_surface = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption('Ping Pong')

async def main():    
    running = True
    clock = pygame.time.Clock()


    ball_surf = pygame.image.load(join('images', 'meteor.png')).convert_alpha()
    ball_rect = ball_surf.get_frect(center = (WINDOW_WIDTH/2, WINDOW_HEIGHT/2))
    ball_direction = pygame.Vector2(-1, -1).normalize()
    ball_speed = 300

    player1_surf = pygame.Surface((20, 100))
    player1_surf.fill('white')
    player1_rect = player1_surf.get_frect(center = (20, WINDOW_HEIGHT / 2))
    player1_direction = pygame.Vector2()
    player1_speed = 500

    player2_surf = pygame.Surface((20, 100))
    player2_surf.fill('white')
    player2_rect = player2_surf.get_frect(center = (WINDOW_WIDTH - 20, WINDOW_HEIGHT / 2))
    player2_direction = pygame.Vector2()
    player2_speed = 500


    while running:
        dt = clock.tick() / 1000

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False


        keys = pygame.key.get_pressed()

        player1_direction.y = int(keys[pygame.K_s]) - int(keys[pygame.K_w])
        player1_direction = player1_direction.normalize() if player1_direction else player1_direction
        player1_rect.center += player1_direction * player1_speed * dt

        player2_direction.y = int(keys[pygame.K_DOWN]) - int(keys[pygame.K_UP])
        player2_direction = player2_direction.normalize() if player2_direction else player2_direction
        player2_rect.center += player2_direction * player2_speed * dt

        if player1_rect.top < 0: 
            player1_rect.top = 0 
        if player2_rect.top < 0:
            player2_rect.top = 0

        if player1_rect.bottom > WINDOW_HEIGHT:
            player1_rect.bottom = WINDOW_HEIGHT
        if player2_rect.bottom > WINDOW_HEIGHT:
            player2_rect.bottom = WINDOW_HEIGHT

        ball_rect.x += ball_direction.x * ball_speed * dt
        ball_rect.y += ball_direction.y * ball_speed * dt

        if ball_rect.colliderect(player1_rect):
            ball_direction.x *= -1
            ball_direction.x += 0.4
        if ball_rect.colliderect(player2_rect):
            ball_direction.x *= -1
            ball_direction.x += 0.4
            
        if ball_rect.bottom >= WINDOW_HEIGHT or ball_rect.top <= 0:
            ball_direction.y *= -1
        ball_rect.center += ball_direction * ball_speed * dt 


        display_surface.fill('black')
        pygame.draw.line(display_surface, 'white', (WINDOW_WIDTH / 2, 0), (WINDOW_WIDTH / 2, WINDOW_HEIGHT), 2)
        display_surface.blit(ball_surf, ball_rect)
        display_surface.blit(player1_surf, player1_rect)
        display_surface.blit(player2_surf, player2_rect)

        pygame.display.update()

        await asyncio.sleep(0)

    pygame.quit()

asyncio.run(main())